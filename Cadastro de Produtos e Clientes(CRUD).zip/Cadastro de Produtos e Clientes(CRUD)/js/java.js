function rota() {
    var site = "view/telalogin.php";
    window.location.href = site;
}