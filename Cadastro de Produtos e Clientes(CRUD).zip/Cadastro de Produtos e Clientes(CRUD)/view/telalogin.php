<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/estilo.css">
    <title>Login</title>
</head>
<body>
<h1 class="titulologin">Acesso ao sistema</h1>
<form action="" method="">
    <fieldset id="cxlogin">
        <legend>Sistema de Cadastro</legend>
        Login:
        <input type="email" name="cxemail"> <br><br>
        Senha:
        <input type="password" name="cxsenha"> <br><br>
        <input type="submit" value="Acessar"> <br>
        <figure id="cadeado">
            <img src="../img/cadeado.png" alt="cadeado" class="figura1">


        </figure>


    </fieldset>
</form>

    
</body>
</html>