<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/estilo.css">

    <title>Menu</title>
</head>
<body id="fundomenu">
    <h1 class="h1menu">Menu Inicial </h1>
    <section id="menu">
        <h2>Cliente</h2>
    <a href="cadastrocliente.php">Cadastrar Cliente </a><br><br><br>
    <a href="../model/listarcliente.php">Listar Cliente</a><br><br><br>
    <a href="../model/pesquisanomecliente.php">Pesquisa Cliente</a><br><br><br>
<hr>
<h2>Produto</h2>
    <a href="cadastroproduto.php">Cadastrar Produto</a><br><br><br>
    <a href="../model/listarproduto.php">Listar Produto</a><br><br><br>
    <a href="../model/pesquisanomeproduto.php">Pesquisa Produto</a><br><br><br>




    </section>
    
    <br>
</body>
</html>
